import { combineReducers } from 'redux';
import step from './step';

export default combineReducers({ step });
